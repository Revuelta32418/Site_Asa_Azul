<?php
function buscarPedidoPendente($conexao, $usuarioId)
{
    $stmt = mysqli_prepare(
        $conexao,
        "SELECT id FROM pedidos_guia WHERE usuario_id = ? AND status = 'pendente' LIMIT 1"
    );
    mysqli_stmt_bind_param($stmt, "i", $usuarioId);
    mysqli_stmt_execute($stmt);
    $linha = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    return $linha ?: null;
}

function criarPedidoGuia($conexao, $usuarioId, array $d)
{
    $stmt = mysqli_prepare(
        $conexao,
        "INSERT INTO pedidos_guia (usuario_id, telefone, regiao, especialidade, experiencia)
         VALUES (?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param(
        $stmt, "issss",
        $usuarioId, $d['telefone'], $d['regiao'], $d['especialidade'], $d['experiencia']
    );
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
}

// Retorna todos os pedidos pendentes com dados do usuário
function listarPedidosGuiaPendentes($conexao)
{
    $sql = "SELECT p.*, u.nome, u.email 
            FROM pedidos_guia p 
            INNER JOIN usuarios u ON p.usuario_id = u.id 
            WHERE p.status = 'pendente' 
            ORDER BY p.id DESC";
            
    $resultado = mysqli_query($conexao, $sql);
    $pedidos = [];
    
    if ($resultado) {
        while ($linha = mysqli_fetch_assoc($resultado)) {
            $pedidos[] = $linha;
        }
    }
    
    return $pedidos;
}

// Aprova o pedido e altera o tipo do usuário para 'guia'
function aprovarPedidoGuia($conexao, $pedidoId)
{
    mysqli_begin_transaction($conexao);
    try {
        $stmt = mysqli_prepare($conexao, "SELECT usuario_id FROM pedidos_guia WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $pedidoId);
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $pedido = mysqli_fetch_assoc($res);
        mysqli_stmt_close($stmt);

        if ($pedido) {
            $usuarioId = $pedido['usuario_id'];

            // Atualiza status do pedido
            $stmt1 = mysqli_prepare($conexao, "UPDATE pedidos_guia SET status = 'aprovado' WHERE id = ?");
            mysqli_stmt_bind_param($stmt1, "i", $pedidoId);
            mysqli_stmt_execute($stmt1);
            mysqli_stmt_close($stmt1);

            // Torna o usuário um guia
            $stmt2 = mysqli_prepare($conexao, "UPDATE usuarios SET tipo = 'guia' WHERE id = ?");
            mysqli_stmt_bind_param($stmt2, "i", $usuarioId);
            mysqli_stmt_execute($stmt2);
            mysqli_stmt_close($stmt2);

            mysqli_commit($conexao);
            return true;
        }
    } catch (Exception $e) {
        mysqli_rollback($conexao);
    }
    return false;
}

// Recusa o pedido
function recusarPedidoGuia($conexao, $pedidoId)
{
    $stmt = mysqli_prepare($conexao, "UPDATE pedidos_guia SET status = 'recusado' WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $pedidoId);
    $sucesso = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $sucesso;
}